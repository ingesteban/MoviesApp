package dev.esteban.test.presentation.movies

import android.arch.lifecycle.Observer
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import dev.esteban.test.R
import dev.esteban.test.data.entities.Resource
import dev.esteban.test.data.entities.ResourceState
import dev.esteban.test.data.entities.ResponseListMovies
import dev.esteban.test.presentation.utils.BaseActivity
import kotlinx.android.synthetic.main.activity_movies.*
import org.koin.android.ext.android.inject
import org.koin.android.viewmodel.ext.android.viewModel

class MoviesActivity : BaseActivity() {

    private val listMoviesVM: MoviesViewModel by viewModel()
    private val moviesAdapter: MoviesAdapter by inject()

    companion object{
        const val PARAMETER_MOVIES = "PARAMETER_MOVIES"
    }

    override fun getLayoutId(): Int {
        return R.layout.activity_movies
    }

    override fun initializeView() {
        initObservers()

        //Se inicializa el recycler
        val linearManager = LinearLayoutManager(this)

        listRvMovies.adapter = moviesAdapter
        listRvMovies.layoutManager = linearManager

        //Valida que valor trae en los extras para determinar que tipo de petición genera

        /*
        intent.extras?.let {
            if (it.containsKey(PARAMETER_MOVIES)){
                when(it.getString(PARAMETER_MOVIES)){
                    TOP_RATED -> {
                        showMessageInformation(it.getString(PARAMETER_MOVIES)!!)
                    }
                    POPULAR -> {
                        showMessageInformation(it.getString(PARAMETER_MOVIES)!!)
                    }
                    UPCOMING -> {
                        //Se llama al servicio que obtiene los estrenos
                        listMoviesVM.getUpcoming()
                    }
                    else -> {
                        showEmptyData()
                    }
                }
            }
        }
        */
        listMoviesVM.getUpcoming()

    }

    private fun initObservers() {
        //Observador del request init
        /*

            listMoviesVM.getListMoviesState().observe(this, Observer<ListMoviesState> { requestState ->
                when(requestState){
                    ListMoviesState.Loading -> listPbLoading.visibility = View.VISIBLE
                    is ListMoviesState.Success -> {

                        showData(requestState.listMovies)
                    }
                    is ListMoviesState.Error -> {
                        showEmptyData()

                        showMessageInformation(requestState.message)
                    }
                }
            })
        */

        listMoviesVM.getListMoviesState().observe(this, Observer { render(it) })

    }

    private fun render(it: Resource<ResponseListMovies>?) {
        when (it?.state) {
            ResourceState.LOADING -> listPbLoading.visibility = View.VISIBLE
            ResourceState.SUCCESS -> showData(it)
            ResourceState.ERROR -> onError()
        }
    }

    /**
     * Metodo utilizado para mostrar en pantalla las películas obtenidas
     */
    private fun showData(responseListMovies: Resource<ResponseListMovies>?) {
        responseListMovies?.data?.results?.let {
            listIvEmpty.visibility = View.GONE
            listRvMovies.visibility = View.VISIBLE
            listPbLoading.visibility = View.GONE

            //Se carga el recycler con las películas
            moviesAdapter.setItemsList(it)
        } ?: showEmptyData()
    }

    fun onError(){
        showEmptyData()
        showMessageInformation("")
    }

    /**
     * Metodo utilizado para mostrar el indicador de datos vacios y ocultar el recycler
     */
    private fun showEmptyData() {
        listIvEmpty.visibility = View.VISIBLE
        listRvMovies.visibility = View.GONE
        listPbLoading.visibility = View.GONE
    }
}
