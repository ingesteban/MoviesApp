package dev.esteban.test.data.entities

data class Resource<out T> constructor(
    val state: ResourceState,
    val data: T? = null,
    val message: String? = null,
    val messageResource: Int? = null
)