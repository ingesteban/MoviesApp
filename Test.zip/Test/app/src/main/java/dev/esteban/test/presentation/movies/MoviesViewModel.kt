package dev.esteban.test.presentation.movies

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import dev.esteban.test.data.entities.*
import dev.esteban.test.domain.uc.ListMoviesUC
import io.reactivex.Scheduler
import io.reactivex.disposables.CompositeDisposable
import java.util.logging.Logger

/**
 * Created by Jorge Henao on 5/7/19.
 */
class ListMoviesViewModel(
    private val listMoviesUC: ListMoviesUC,
    private val back: Scheduler,
    private val front: Scheduler,
    private val listMoviesLiveData: MutableLiveData<Resource<ResponseListMovies>>
): ViewModel() {

    // Bolsa de disposables
    private var disposeBag: CompositeDisposable = CompositeDisposable()

    /**
     * Retorna la instancia del LiveData que controla el estado de la petición de películas
     */
    fun getListMoviesState(): LiveData<Resource<ResponseListMovies>> {
        return listMoviesLiveData
    }

    /**
     * Genera la petición de peliculas de estreno
     */
    fun getUpcoming(){
        disposeBag.add(listMoviesUC.getUpcoming()
            .doOnSubscribe {
                //Se muestra el indicador de espera mientras realiza la petición
                listMoviesLiveData.setLoading()
            }
            .subscribeOn(back)
            .observeOn(front)
            .subscribe({
                onSuccess(it)
            }, {error: Throwable ->
                //Se esconde indicador de espera y se muestra mensaje de error
                listMoviesLiveData.setError(error.message)
            })
        )
    }

    fun onSuccess(response : ResponseListMovies?){
        response?.results?.let {
            listMoviesLiveData.setSuccess(response)
        } ?: listMoviesLiveData.setError("La lista esta vacia")

    }


    public override fun onCleared() {
        super.onCleared()
        //Se limpian los Disposable para prevenir memory leaks
        disposeBag.clear()
    }

}