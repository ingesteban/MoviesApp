package dev.esteban.test.data.network

import dev.esteban.test.data.entities.ResponseListMovies
import io.reactivex.Observable
import retrofit2.http.GET

/**
 * Created by Jorge Henao on 5/7/19.
 */
interface ListMoviesApi {

    /**
     * Endpoint encargado de realizar la petición Http del servicio de peliculas de estreno
     */
    @GET("movie/upcoming")
    fun getUpcoming(): Observable<ResponseListMovies>

    /**
     * Endpoint encargado de realizar la petición Http del servicio de peliculas mejor puntuadas
     */
    @GET("movie/top_rated")
    fun getTopRated(): Observable<ResponseListMovies>
}