package dev.esteban.test.presentation.movies

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import dev.esteban.test.R
import dev.esteban.test.data.entities.ResultMovies
import kotlinx.android.synthetic.main.item_recycler_movies.view.*

/**
 * Created by Jorge Henao on 5/8/19.
 */
class MoviesAdapter: RecyclerView.Adapter<MoviesAdapter.MoviesHolder>() {

    private var movies: List<ResultMovies> = listOf()

    /**
     * Este metodo asocia el layout item_recycler_movies.xml con el recyclerView (infla el layout)
     *
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoviesHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recycler_movies, parent, false)

        return MoviesHolder(view)
    }

    /**
     * Cantidad de elementos que contiene la lista de servicios
     */
    override fun getItemCount(): Int {
        return movies.size
    }

    /**
     * Notifica al adapter el cambio en los items a mostrar
     */
    fun setItemsList(moviesList: List<ResultMovies>) {
        movies = moviesList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: MoviesHolder, position: Int) {
        val movie = movies[position]

        holder.movieName.text = movie.originalTitle
        holder.movieScore.text = movie.voteAverage.toString()
        holder.movieLanguage.text = movie.originalLanguage
    }

    class MoviesHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val movieName: TextView = itemView.itemMoviesName
        val movieScore: TextView = itemView.itemMoviesScore
        val movieLanguage: TextView = itemView.itemMoviesLanguage
    }
}