package dev.esteban.test.presentation.utils

import android.support.v7.app.AppCompatActivity
import android.support.v7.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.view.Gravity
import android.widget.Toast
import dev.esteban.test.R
import java.util.ArrayList

/**
 * Created by Jorge Henao on 3/28/19.
 */
abstract class BaseActivity: AppCompatActivity() {

    private val APPLICATION_PERMISSION_ACTIVITY = 2018

    protected var requiredPermissionsGranted: Boolean? = true

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(getLayoutId())

        verificationPermission(getPermissionList())

        initializeView()
    }

    /**
     * Use este metodo para inicializar los componentes de la vista
     */
    protected abstract fun getLayoutId(): Int

    /**
     * Verifica cada uno de los permisos requeridos por la actividad
     */
    private fun verificationPermission(permisosRequeridos: List<String>) {
        if (permisosRequeridos.size > 0) {
            requiredPermissionsGranted = false

            //Lista para los permisos no otorgados
            val permissionsNotGranted = ArrayList<String>()

            //Revisamos cuales de los permisos no estan otorgados
            for (permiso in permisosRequeridos) {
                if (ContextCompat.checkSelfPermission(this, permiso) != PackageManager.PERMISSION_GRANTED) {
                    permissionsNotGranted.add(permiso)
                }
            }

            //Si hay permisos no otorgados, se solicita al usuario autorizacion
            if (!permissionsNotGranted.isEmpty()) {
                ActivityCompat.requestPermissions(
                    this,
                    permissionsNotGranted.toTypedArray(),
                    APPLICATION_PERMISSION_ACTIVITY
                )
            } else {
                //Todos los permisos requeridos estan otorgados
                requiredPermissionsGranted = true
            }
        } else {
            requiredPermissionsGranted = true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        var allPermissionsGranted = true

        if (requestCode == APPLICATION_PERMISSION_ACTIVITY) {
            for (resultado in grantResults) {
                if (resultado == PackageManager.PERMISSION_DENIED) {
                    allPermissionsGranted = false

                    showDialogMessage(
                        getString(R.string.title_permissions),
                        getString(R.string.information_permissions)
                    )
                    break
                }
            }
        }

        requiredPermissionsGranted = allPermissionsGranted
    }

    /**
     * Retorna la lista de permisos que necesita la actividad
     */
    protected open fun getPermissionList(): List<String> = ArrayList()

    abstract fun initializeView()

    /**
     * Muestra un mensaje para notificar el resultado de una operacion
     */
    fun showMessageInformation(message: String) {
        val toast = Toast.makeText(applicationContext, message, Toast.LENGTH_SHORT)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()
    }

    /**
     * Muestra una ventana con un mensaje de error
     */
    fun showDialogMessage(title: String, message: String) {

        if (applicationContext != null || !(applicationContext as AppCompatActivity).isFinishing) {
            val builder = AlertDialog.Builder(this, R.style.TestAlertDialog)
            builder.setPositiveButton("OK") { dialog, which ->
                //No hacer nada
            }

            builder.setTitle(title)
            builder.setMessage(message)
            val currentDialog = builder.create()

            currentDialog.show()
        }
    }

}