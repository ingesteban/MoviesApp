package dev.esteban.test.data.entities

import android.arch.lifecycle.MutableLiveData

fun <T> MutableLiveData<Resource<T>>.setSuccess(data: T? = null) = postValue(Resource(ResourceState.SUCCESS, data))

fun <T> MutableLiveData<Resource<T>>.setLoading() = setValue(Resource(ResourceState.LOADING, value?.data))

fun <T> MutableLiveData<Resource<T>>.setError(message: String? = null, throwable: Throwable? = null) {
    //setValue(Resource(ResourceState.ERROR, value?.data, message, throwable.withResourceError()))
    setValue(Resource(ResourceState.ERROR, value?.data, message))

}


