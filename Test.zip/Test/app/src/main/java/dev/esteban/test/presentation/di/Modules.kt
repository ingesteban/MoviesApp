package dev.esteban.test.presentation.di

import android.arch.lifecycle.MutableLiveData
import dev.esteban.test.data.network.ListMoviesApi
import dev.esteban.test.domain.uc.ListMoviesUC
import dev.esteban.test.presentation.movies.ListMoviesViewModel
import dev.esteban.test.presentation.movies.MoviesAdapter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.core.module.Module
import org.koin.dsl.module
import retrofit2.Retrofit

/**
 * Created by Jorge Henao on 5/8/19.
 */

/**
 * Modulo encargado de instanciar los viewModel
 */
val viewModelModule: Module = module {
    viewModel {
        ListMoviesViewModel(
            listMoviesUC = get(),
            back = Schedulers.io(),
            front = AndroidSchedulers.mainThread(),
            listMoviesLiveData = MutableLiveData()
        )
    }
}

/**
 * Modulo encargado de instanciar los casos de uso
 */
val useCasesModule: Module = module {
    factory { ListMoviesUC(listMoviesApi) }
}

val utilsModule: Module = module {
    factory { MoviesAdapter() }
}

private val retrofit: Retrofit = ManagerNetwork(TestApp.applicationContext().applicationContext).getTheMovieRetrofit()

// Inicializa la instancia que contiene el Endpoint para llamar al servicio que obtiene los listados de peliculas
private val listMoviesApi: ListMoviesApi = retrofit.create(ListMoviesApi::class.java)