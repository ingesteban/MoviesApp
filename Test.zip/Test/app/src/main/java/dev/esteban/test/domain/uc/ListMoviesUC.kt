package dev.esteban.test.domain.uc

import dev.esteban.test.data.entities.ResponseListMovies
import dev.esteban.test.data.network.ListMoviesApi
import io.reactivex.Observable

/**
 * Created by esteban barrios on 5/7/19.
 */
class ListMoviesUC(private val listMovies: ListMoviesApi) {

    /**
     * Retorna el Observable encargado de realizar la petición Http al servicio de estrenos
     */
    fun getUpcoming(): Observable<ResponseListMovies> {
        return listMovies.getUpcoming()
    }
}