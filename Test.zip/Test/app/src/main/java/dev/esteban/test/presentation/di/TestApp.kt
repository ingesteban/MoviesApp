package dev.esteban.test.presentation.di

import android.app.Application
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

/**
 * Created by Jorge Henao on 3/28/19.
 */
class TestApp: Application() {

    override fun onCreate() {
        super.onCreate()

        // Start Koin
        startKoin{
            androidLogger()
            androidContext(this@TestApp)
            modules(
                viewModelModule,
                useCasesModule,
                utilsModule
            )
        }
    }

    init {
        instance = this
    }

    companion object {
        private var instance: TestApp? = null
        fun applicationContext(): TestApp {
            return instance!!
        }
    }
}