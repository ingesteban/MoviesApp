package dev.esteban.test.data.entities

import com.squareup.moshi.Json

/**
 * Created by Jorge Henao on 5/7/19.
 */
class RequestListMovies {

    @field:Json(name = "api_key")
    var apiKey: String = ""
    @field:Json(name = "language")
    var language: String = "en-US"
    @field:Json(name = "page")
    var page: Int = 1
}